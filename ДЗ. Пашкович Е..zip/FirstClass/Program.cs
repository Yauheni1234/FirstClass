﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

Console.WriteLine("Hello Евгений");
string user = Console.ReadLine();
Console.WriteLine(user);
